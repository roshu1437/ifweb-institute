<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/materialize.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/style.css')?>">